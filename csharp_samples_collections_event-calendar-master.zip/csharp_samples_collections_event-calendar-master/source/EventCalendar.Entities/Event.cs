﻿using System;
using System.Collections.Generic;

namespace EventCalendar.Entities
{
    public class Event : IComparable<Event>
    {
        string _title;
        DateTime _date;
        Person _invitor;
        int _maxParticipators;
        private readonly ICollection<Person> _participators;

        public string Title
        {
            get { return _title; }
        }

        public DateTime Date
        {
            get { return _date; }
        }

        public Person Invitor
        {
            get { return _invitor; }
        }

        public int MaxParticipators
        {
            get { return _maxParticipators;  }
        }

        public int CompareTo(Event other)
        {
            return Title.CompareTo(other.Title);
        }

        public ICollection<Person> Participators
        {
            get { return _participators; }
        }

        public bool InsertParticipator(Person person)
        {
            if (person != null)
            {
                _participators.Add(person);

                return true;
            }
            return false;
        }

        public bool RemoveParticipator(Person person)
        {
            if (_participators.Contains(person))
            {
                _participators.Remove(person);
                return true;
            }
            return false;
        }

        public Event(Person invitor, string title, DateTime date, int maxParticipators)
        {
            _title = title;
            _date = date;
            _invitor = invitor;
            _maxParticipators = maxParticipators;
            _participators = new List<Person>();
        }

        public string GetTitle()
        {
            return Title;
        }
    }
}