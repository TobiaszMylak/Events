﻿using System;
using System.Collections.Generic;

namespace EventCalendar.Entities
{
    public class SmallEvent : Event
    {
        public SmallEvent(Person invitor, string title, DateTime date, int maxParticipators) : base(invitor, title, date, maxParticipators)
        {
            
        }
    }
}