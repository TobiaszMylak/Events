﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using EventCalendar.Entities;
using static System.String;

namespace EventCalendar.Logic
{
    public class Controller
    {
        private readonly ICollection<Event> _events;
        int _eventcount = 0;
        public int EventsCount { get { return _eventcount; } }

        public Controller()
        {
            _events = new List<Event>();
        }

        /// <summary>
        /// Ein Event mit dem angegebenen Titel und dem Termin wird für den Einlader angelegt.
        /// Der Titel muss innerhalb der Veranstaltungen eindeutig sein und das Datum darf nicht
        /// in der Vergangenheit liegen.
        /// Mit dem optionalen Parameter maxParticipators kann eine Obergrenze für die Teilnehmer festgelegt
        /// werden.
        /// </summary>
        /// <param name="invitor"></param>
        /// <param name="title"></param>
        /// <param name="dateTime"></param>
        /// <param name="maxParticipators"></param>
        /// <returns>Wurde die Veranstaltung angelegt</returns>
        public bool CreateEvent(Person invitor, string title, DateTime dateTime, int maxParticipators = 0)
        {
            int result = DateTime.Compare(DateTime.Now, dateTime);
            if (invitor != null && result < 0 && title != "")
            {
                Event ev = new Event(invitor, title, dateTime, maxParticipators);
                _events.Add(ev);
                _eventcount++;
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// Liefert die Veranstaltung mit dem Titel
        /// </summary>
        /// <param name="title"></param>
        /// <returns>Event oder null, falls es keine Veranstaltung mit dem Titel gibt</returns>
        public Event GetEvent(string title)
        {
            Event[] eventarray = new Event[_events.Count];
            for (int i = 0;  i < _events.Count; i++)
            {
                eventarray[i] = _events.ElementAt<Event>(i);
                if (eventarray[i].Title.Equals(title))
                {
                    return eventarray[i];
                }
            }
            return null;
        }

        /// <summary>
        /// Person registriert sich für Veranstaltung.
        /// Eine Person kann sich zu einer Veranstaltung nur einmal registrieren.
        /// </summary>
        /// <param name="person"></param>
        /// <param name="ev">Veranstaltung</param>
        /// <returns>War die Registrierung erfolgreich?</returns>
        public bool RegisterPersonForEvent(Person person, Event ev)
        {
            if (ev != null)
            {
                bool insert = ev.InsertParticipator(person);
                return insert;
            }
            return false;
        }

        /// <summary>
        /// Person meldet sich von Veranstaltung ab
        /// </summary>
        /// <param name="person"></param>
        /// <param name="ev">Veranstaltung</param>
        /// <returns>War die Abmeldung erfolgreich?</returns>
        public bool UnregisterPersonForEvent(Person person, Event ev)
        {
            bool remove = ev.RemoveParticipator(person);
            return remove;
        }

        /// <summary>
        /// Liefert alle Teilnehmer an der Veranstaltung.
        /// Sortierung absteigend nach der Anzahl der Events der Personen.
        /// Bei gleicher Anzahl nach dem Namen der Person (aufsteigend).
        /// </summary>
        /// <param name="ev"></param>
        /// <returns>Liste der Teilnehmer oder null im Fehlerfall</returns>
        public IList<Person> GetParticipatorsForEvent(Event ev)
        {
            return ev.Participators as IList<Person>;
        }

        /// <summary>
        /// Liefert alle Veranstaltungen der Person nach Datum (aufsteigend) sortiert.
        /// </summary>
        /// <param name="person"></param>
        /// <returns>Liste der Veranstaltungen oder null im Fehlerfall</returns>
        public List<Event> GetEventsForPerson(Person person)
        {
            List<Event> participantsevent = new List<Event>();
            Event[] eventarray = new Event[_events.Count];
            for (int i = 0; i < _events.Count; i++)
            {
                eventarray[i] = _events.ElementAt<Event>(i);
                if (eventarray[i].Participators.Contains(person))
                {
                    participantsevent.Add(eventarray[i]);
                }
            }
            if (participantsevent.Count > 0)
            {
                return participantsevent;
            }
            return null;
        }

        /// <summary>
        /// Liefert die Anzahl der Veranstaltungen, für die die Person registriert ist.
        /// </summary>
        /// <param name="participator"></param>
        /// <returns>Anzahl oder 0 im Fehlerfall</returns>
        public int CountEventsForPerson(Person participator)
        {
            Event[] eventarray = new Event[_events.Count];
            int cnt = 0;
            for (int i = 0; i < _events.Count; i++)
            {
                eventarray[i] = _events.ElementAt<Event>(i);
                if (eventarray[i].Participators.Contains(participator))
                {
                    cnt++;
                }
            }
            return cnt;
        }

    }
}
